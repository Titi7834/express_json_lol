# Liste des Champions LOL

Ce projet est une application web permettant de gérer une liste de champions de League of Legends. Vous pouvez ajouter, modifier, supprimer et filtrer les champions par lane, ainsi que voir les statistiques des lanes.

## Fonctionnalités

- Ajouter un champion
- Modifier un champion
- Supprimer un champion
- Filtrer les champions par lane
- Voir les statistiques des lanes

## Prérequis

- Node.js
- npm (Node Package Manager)


## Structure du Projet

- [index.html](http://_vscodecontentref_/0) : Le fichier HTML principal.
- [styles.css](http://_vscodecontentref_/1) : Le fichier CSS pour le style de l'application.
- [script.js](http://_vscodecontentref_/2) : Le fichier JavaScript pour la logique de l'application.
- [server.js](http://_vscodecontentref_/3) : Le fichier de configuration du serveur.
- [db.json](http://_vscodecontentref_/4) : Le fichier de base de données JSON.

## Routes API

### GET /champions/filter/:lane

Retourne uniquement les champions d’une lane donnée.

### GET /champions/lane-stats

Retourne le nombre de champions par lane.

## Utilisation

### Ajouter un Champion

Remplissez le formulaire avec le nom, la lane, le type et l'URL de l'image du champion, puis cliquez sur "Ajouter".

### Modifier un Champion

Cliquez sur le bouton "Modifier" à côté du champion que vous souhaitez modifier, puis mettez à jour les informations dans les invites.

### Supprimer un Champion

Cliquez sur le bouton "Supprimer" à côté du champion que vous souhaitez supprimer.

### Filtrer par Lane

Sélectionnez une lane dans le menu déroulant et cliquez sur "Filtrer" pour afficher uniquement les champions de cette lane.

### Voir les Statistiques des Lanes

Cliquez sur "Voir les statistiques" pour afficher le nombre de champions par lane avec les images correspondantes.

