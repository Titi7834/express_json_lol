// Une liste de tous les champions de League of Legends afin que l'utilisateur ajoutte un vrai personnage
let AllChampions = [
    { name: 'Aatrox'},
    { name: 'Ahri'},
    { name: 'Akali'},
    { name: 'Akshan'},
    { name: 'Alistar'},
    { name: 'Ambessa'},
    { name: 'Amumu'},
    { name: 'Anivia'},
    { name: 'Annie'},
    { name: 'Aphelios'},
    { name: 'Ashe'},
    { name: 'Aurelion Sol'},
    { name: 'Aurora'},
    { name: 'Azir'},
    { name: 'Bard'},
    { name : 'Bel\'Veth'},
    { name: 'Blitzcrank'},
    { name: 'Brand'},
    { name: 'Braum'},
    { name: 'Briar'},
    { name: 'Caitlyn'},
    { name: 'Camille'},
    { name: 'Cassiopeia'},
    { name: 'Cho\'Gath'},
    { name: 'Corki'},
    { name: 'Darius'},
    { name: 'Diana'},
    { name: 'Dr. Mundo'},
    { name: 'Draven'},
    { name: 'Ekko'},
    { name: 'Elise'},
    { name: 'Evelynn'},
    { name: 'Ezreal'},
    { name: 'Fiddlesticks'},
    { name: 'Fiora'},
    { name: 'Fizz'},
    { name: 'Galio'},
    { name: 'Gangplank'},
    { name: 'Garen'},
    { name: 'Gnar'},
    { name: 'Gragas'},
    { name: 'Graves'},
    { name: 'Gwen'},
    { name: 'Hecarim'},
    { name: 'Heimerdinger'},
    { name: 'Hwei'},
    { name: 'Illaoi'},
    { name: 'Irelia'},
    { name: 'Ivern'},
    { name: 'Janna'},
    { name: 'Jarvan IV'},
    { name: 'Jax'},
    { name: 'Jayce'},
    { name: 'Jhin'},
    { name: 'Jinx'},
    { name: 'K\'santé'},
    { name: 'Kai\'Sa'},
    { name: 'Kalista'},
    { name: 'Karma'},
    { name: 'Karthus'},
    { name: 'Kassadin'},
    { name: 'Katarina'},
    { name: 'Kayle'},
    { name: 'Kayn'},
    { name: 'Kennen'},
    { name: 'Kha\'Zix'},
    { name: 'Kindred'},
    { name: 'Kled'},
    { name: 'Kog\'Maw'},
    { name: 'LeBlanc'},
    { name: 'Lee Sin'},
    { name: 'Leona'},
    { name: 'Lillia'},
    { name: 'Lissandra'},
    { name: 'Lucian'},
    { name: 'Lulu'},
    { name: 'Lux'},
    { name: 'Malphite'},
    { name: 'Malzahar'},
    { name: 'Maokai'},
    { name: 'Master Yi'},
    { name: 'Miss Fortune'},
    { name: 'Milio'},
    { name: 'Mordekaiser'},
    { name: 'Morgana'},
    { name: 'Naafiri'},
    { name: 'Nami'},
    { name: 'Nasus'},
    { name: 'Nautilus'},
    { name: 'Neeko'},
    { name: 'Nidalee'},
    { name: 'Nilah'},
    { name: 'Nocturne'},
    { name: 'Nunu & Willump'},
    { name: 'Olaf'},
    { name: 'Orianna'},
    { name: 'Ornn'},
    { name: 'Pantheon'},
    { name: 'Poppy'},
    { name: 'Pyke'},
    { name: 'Qiyana'},
    { name: 'Quinn'},
    { name: 'Rakan'},
    { name: 'Rammus'},
    { name: 'Rek\'Sai'},
    { name: 'Rell'},
    { name: 'Renata Glasc'},
    { name: 'Renekton'},
    { name: 'Rengar'},
    { name: 'Riven'},
    { name: 'Rumble'},
    { name: 'Ryze'},
    { name: 'Samira'},
    { name: 'Sejuani'},
    { name: 'Senna'},
    { name: 'Seraphine'},
    { name: 'Sett'},
    { name: 'Shaco'},
    { name: 'Shen'},
    { name: 'Shyvana'},
    { name: 'Singed'},
    { name: 'Sion'},
    { name: 'Sivir'},
    { name: 'Skarner'},
    { name: 'Smolder'},
    { name: 'Sona'},
    { name: 'Soraka'},
    { name: 'Swain'},
    { name: 'Sylas'},
    { name: 'Syndra'},
    { name: 'Tahm Kench'},
    { name: 'Taliyah'},
    { name: 'Talon'},
    { name: 'Taric'},
    { name: 'Teemo'},
    { name: 'Thresh'},
    { name: 'Tristana'},
    { name: 'Trundle'},
    { name: 'Tryndamere'},
    { name: 'Twisted Fate'},
    { name: 'Twitch'},
    { name: 'Udyr'},
    { name: 'Urgot'},
    { name: 'Varus'},
    { name: 'Vayne'},
    { name: 'Veigar'},
    { name: 'Vel\'Koz'},
    { name: 'Vex'},
    { name: 'Vi'},
    { name: 'Viego'},
    { name: 'Viktor'},
    { name: 'Vladimir'},
    { name: 'Volibear'},
    { name: 'Warwick'},
    { name: 'Wukong'},
    { name: 'Xayah'},
    { name: 'Xerath'},
    { name: 'Xin Zhao'},
    { name: 'Yasuo'},
    { name: 'Yone'},
    { name: 'Yorick'},
    { name: 'Yuumi'},
    { name: 'Zac'},
    { name: 'Zed'},
    { name: 'Zeri'},
    { name: 'Ziggs'},
    { name: 'Zilean'},
    { name: 'Zoe'},
    { name: 'Zyra'}
];

// Une liste de toutes les lanes pour que l'utilisateur ne puisse pas renseigner de mauvaises lanes
let AllLanes = [
    { name: 'Top'},
    { name: 'Jungle'},
    { name: 'Mid'},
    { name: 'Adc'},
    { name: 'Support'}
];

// Une liste de tous les types pour que l'utilisateur ne puisse pas renseigner de mauvais types
let AllTypes = [
    { name: 'Tireur'},
    { name: 'Tank'},
    { name: 'Assassin'},
    { name: 'Mage'},
    { name: 'Bruiser'},
    { name: 'Marksman'},
    { name: 'Support'},
    { name: 'Fighter'},
    { name: 'Specialiste'},
];

// Une liste contenant les images des lanes pour avoir les symboles sur la page
const laneImages = {
    Top: 'https://ih1.redbubble.net/image.2355944263.7654/raf,360x360,075,t,fafafa:ca443f4786.jpg',
    Jungle: 'https://ih1.redbubble.net/image.2354145971.1555/raf,360x360,075,t,fafafa:ca443f4786.jpg',
    Mid: 'https://ih1.redbubble.net/image.2354245893.4601/raf,360x360,075,t,fafafa:ca443f4786.jpg',
    Adc: 'https://ih1.redbubble.net/image.2354178297.2522/raf,360x360,075,t,fafafa:ca443f4786.jpg',
    Support: 'https://ih1.redbubble.net/image.2354279571.5595/raf,360x360,075,t,fafafa:ca443f4786.jpg'
};

const loadChampions = async (filterLane = '') => {
    try {
        // Construire l'URL en fonction de la lane filtrée
        const url = filterLane ? `/champions/filter/${filterLane}` : '/api/champions';
        const response = await fetch(url);

        // Vérifier la réponse
        if (!response.ok) {
            throw new Error(`Erreur HTTP ${response.status}: ${response.statusText}`);
        }

        // Convertir la réponse en JSON
        const champions = await response.json();

        // Référencer l'élément DOM pour afficher les champions
        const championsList = document.getElementById('champions');
        championsList.innerHTML = ''; // Réinitialiser le contenu

        // Parcourir les champions et les ajouter au DOM
        champions.forEach(champion => {
            // Créer les éléments nécessaires
            const li = document.createElement('li');
            const img = document.createElement('img');
            img.src = champion.image;
            img.alt = champion.name;
            img.className = 'champion-image';

            const championInfo = document.createElement('div');
            championInfo.className = 'champion-info';

            // Nom
            const nameDiv = document.createElement('div');
            nameDiv.className = 'champion-name';
            nameDiv.textContent = champion.name;

            // Lane
            const laneDiv = document.createElement('div');
            laneDiv.className = 'champion-lane';
            laneDiv.textContent = champion.lane;

            // Type
            const typeDiv = document.createElement('div');
            typeDiv.className = 'champion-type';
            typeDiv.textContent = champion.type;

            // Ajouter les informations au conteneur
            championInfo.appendChild(nameDiv);
            championInfo.appendChild(laneDiv);
            championInfo.appendChild(typeDiv);

            // Bouton de modification
            const editBtn = document.createElement('button');
            editBtn.textContent = 'Modifier';
            editBtn.className = 'edit';
            editBtn.onclick = () => {
                const updatedChampion = {
                    name: prompt('Nom:', champion.name) || champion.name,
                    lane: prompt('Lane:', champion.lane) || champion.lane,
                    type: prompt('Type:', champion.type) || champion.type,
                    image: prompt('Image URL:', champion.image) || champion.image
                };
                updateChampion(champion.id, updatedChampion);
            };

            // Bouton de suppression
            const deleteBtn = document.createElement('button');
            deleteBtn.textContent = 'Supprimer';
            deleteBtn.className = 'delete';
            deleteBtn.onclick = () => deleteChampion(champion.id);

            // Ajouter tous les éléments au <li>
            li.appendChild(img);
            li.appendChild(championInfo);
            li.appendChild(editBtn);
            li.appendChild(deleteBtn);

            // Ajouter le <li> à la liste des champions
            championsList.appendChild(li);
        });
    } catch (error) {
        console.error('Erreur lors du chargement des champions:', error);
    }
};


// Charger des champions au démarrage
loadChampions();

const addChampions = async (newChampion) => {
    try {
        let hasError = false;

        // Vérifier si le champion fait partie du registre AllChampions
        const isValidChampion = AllChampions.some(champ => champ.name.toLowerCase() === newChampion.name.toLowerCase());
        if (!isValidChampion) {
            document.getElementById('nameError').textContent = 'Ce champion n\'existe pas dans LOL';
            document.getElementById('nameError').style.display = 'block';
            hasError = true;
        } else {
            document.getElementById('nameError').style.display = 'none';
        }

        // Vérifier si le lane fait partie du registre AllLanes
        const isValidLane = AllLanes.some(lane => lane.name.toLowerCase() === newChampion.lane.toLowerCase());
        if (!isValidLane) {
            document.getElementById('laneError').textContent = 'Cette lane n\'existe pas dans LOL';
            document.getElementById('laneError').style.display = 'block';
            hasError = true;
        } else {
            document.getElementById('laneError').style.display = 'none';
        }

        // Vérifier si le type fait partie du registre AllTypes
        const isValidType = AllTypes.some(type => type.name.toLowerCase() === newChampion.type.toLowerCase());
        if (!isValidType) {
            document.getElementById('typeError').textContent = 'Ce type n\'existe pas dans LOL';
            document.getElementById('typeError').style.display = 'block';
            hasError = true;
        } else {
            document.getElementById('typeError').style.display = 'none';
        }

        if (hasError) {
            return; // Ne pas ajouter le champion si il y a des erreurs
        }

        // Si le champion, lane, et type sont valides, procéder à l'ajout
        const response = await fetch('/api/champions', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(newChampion)
        });

        if (!response.ok) {
            throw new Error('Erreur lors de l\'ajout du champion');
        }

        const createdChampion = await response.json();
        console.log('Nouveau Champion ajouté :', createdChampion);

        // Vous pouvez ensuite recharger la liste des champions pour la voir apparaître
        loadChampions();
    } catch (error) {
        console.error(error);
    }
};

// Ajouter un événement pour le formulaire de création
document.getElementById('createChampionForm').onsubmit = (event) => {
    event.preventDefault();
    const name = document.getElementById('championName').value;
    const lane = document.getElementById('championLane').value;
    const type = document.getElementById('championType').value;
    const image = document.getElementById('championImage').value;
    addChampions({ name, lane, type, image });
};

// Modifier un champion
const updateChampions = async (id, updatedChampion) => {
    try {
        let hasError = false;

        // Vérifier si le champion fait partie du registre AllChampions
        const isValidChampion = AllChampions.some(champ => champ.name.toLowerCase() === updatedChampion.name.toLowerCase());
        if (!isValidChampion) {
            alert('Erreur : Ce champion n\'existe pas dans LOL');
            hasError = true;
        }

        // Vérifier si le lane fait partie du registre AllLanes
        const isValidLane = AllLanes.some(lane => lane.name.toLowerCase() === updatedChampion.lane.toLowerCase());
        if (!isValidLane) {
            alert('Erreur : Cette lane n\'existe pas dans LOL');
            hasError = true;
        }

        // Vérifier si le type fait partie du registre AllTypes
        const isValidType = AllTypes.some(type => type.name.toLowerCase() === updatedChampion.type.toLowerCase());
        if (!isValidType) {
            alert('Erreur : Ce type n\'existe pas dans LOL');
            hasError = true;
        }

        if (hasError) {
            return; // Ne pas modifier le champion si il y a des erreurs
        }

        // Si le champion, lane, et type sont valides, procéder à la modification
        const response = await fetch(`/api/champions/${id}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(updatedChampion)
        });

        if (!response.ok) {
            throw new Error('Erreur lors de la modification du champion');
        }

        const result = await response.json();
        console.log('Champion modifié :', result);

        // Vous pouvez ensuite recharger la liste des champions pour voir les modifications
        loadChampions();
    } catch (error) {
        console.error(error);
    }
};

// Supprimer un champion
const deleteChampions = async (id) => {
    try {
        const response = await fetch(`/api/champions/${id}`, {
            method: 'DELETE'
        });

        if (!response.ok) {
            throw new Error('Erreur lors de la suppression du champion');
        }

        console.log('Champion supprimé');

        // Vous pouvez ensuite recharger la liste des champions pour voir les modifications
        loadChampions();
    } catch (error) {
        console.error(error);
    }
};

const applyLaneFilter = async () => {
    const lane = document.getElementById('laneFilter').value; // Récupère la valeur sélectionnée
    loadChampions(lane);
};

const getLaneStats = async () => {
    try {
        // Envoie une requête GET à l'API pour récupérer les statistiques des lanes
        const response = await fetch('/champions/lane-stats');
        const stats = await response.json();

        // Référence à l'élément sur la page où les statistiques seront affichées
        const championsList = document.getElementById('champions');
        championsList.innerHTML = ''; // Réinitialise la liste

        // Parcourt les statistiques reçues et crée des éléments pour chaque lane
        Object.entries(stats).forEach(([lane, count]) => {
            const li = document.createElement('li');

            // Ajout d'une image associée à chaque lane
            const img = document.createElement('img');
            img.src = laneImages[lane]; // Récupère l'image associée à la lane depuis un objet `laneImages`
            img.alt = `${lane} icon`; // Texte alternatif pour l'image
            img.style.width = '50px';
            img.style.height = '50px';
            img.style.marginRight = '10px';

            // Ajout du texte pour afficher le nombre de champions dans la lane
            const text = document.createElement('span');
            text.textContent = `${lane}: ${count} champions`;

            // Assemble les éléments et les ajoute à la liste
            li.appendChild(img);
            li.appendChild(text);
            championsList.appendChild(li);
        });
    } catch (error) {
        // Gère les erreurs éventuelles lors de la récupération des données
        console.error('Erreur lors de la récupération des statistiques:', error);
    }
};
