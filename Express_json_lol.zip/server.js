const express = require('express');
const path = require('path');
const jsonServer = require('json-server');

const app = express();
const PORT = 3001;

const listeLane = ["Top","Jungle","Mid","Adc","Support"];

// Servir les fichiers frontend
app.use(express.static(path.join(__dirname, 'public')));

// Intégrer JSON Server
const router = jsonServer.router('db.json');
app.use('/api', router);

app.listen(PORT, () => {
    console.log(`Serveur en cours d'exécution sur http://localhost:${PORT}`);
});

function capitalizeFirstLetter(string) {
    if (!string || typeof string !== 'string') return ''; // Gère les cas où l'entrée est vide ou non une chaîne
    return string.charAt(0).toUpperCase() + string.slice(1).toLowerCase();
}


app.get('/champions/filter/:lane', (req, res) => {
    const { lane } = req.params; // Récupère la lane depuis l'URL
    const strLane = capitalizeFirstLetter(lane.toString()); // Formatte la lane
    const db = router.db; // Accès à la base de données JSON Server
    const champs = db.get('champions').value(); // Récupère tous les champions

    // Filtrer les champions par la lane demandée
    const champsListe = champs.filter(champ => champ.lane === strLane);

    if (champsListe.length > 0) {
        res.json(champsListe); // Retourne le tableau des champions trouvés
    } else {
        res.status(404).json({ message: 'Aucun champion trouvé pour cette lane.' }); // Retourne une erreur 404 accompagnée d'un message d'erreur si il n'y a aucun élément
    }
});


// Route GET pour obtenir les statistiques des champions par "lane"
app.get('/champions/lane-stats', (req, res) => {
    const db = router.db;
    const champs = db.get('champions').value();

    // Utilise la méthode reduce pour compter les champions par "lane"
    const countByLane = champs.reduce((acc, personnage) => {
        // Extrait la lane du champion actuel
        const lane = personnage.lane;

        // Vérifie si la lane est dans la liste des lanes valides
        if (listeLane.find(e => e == lane)) {
            // Incrémente le compteur pour la lane correspondante
            acc[lane] = (acc[lane] || 0) + 1;
        }

        return acc; // Retourne l'accumulateur à chaque itération
    }, {});
    // Renvoie les résultats sous forme de JSON
    res.json(countByLane);
});
